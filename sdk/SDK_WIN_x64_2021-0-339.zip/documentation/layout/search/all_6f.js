var searchData=
[
  ['origin',['origin',['../struct_l_o_rect2_d.html#a4f3cbf54bd36fc71829054aee1c48267',1,'LORect2D']]]
];
