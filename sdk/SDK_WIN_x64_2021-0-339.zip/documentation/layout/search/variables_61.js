var searchData=
[
  ['alpha',['alpha',['../struct_s_u_color.html#a77a421e57b9fcb475804ac425b337e9b',1,'SUColor']]]
];
